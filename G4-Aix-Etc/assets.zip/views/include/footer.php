<div class="footer">
    <div class="section group">
        <ul>
            <li>Plan du Site:</li>
            <li>Accueil</li>
            <li>Lieux culturels</li>
            <li>Bars</li>
            <li>Restaurants</li>
            <li>Évènements</li>
            <li>Contact</li>
        </ul>
    </div>
    <div class="reseau_mentionL">
        <div class="reseau">
            <img alt="facebook" src="./assets/images/icon/facebook.png" />
            <img alt="twitter" src="./assets/images/icon/instagram.png" />
        </div>
        <p>Mentions légales :
            <a href="index.php?action=7">accéder</a></p>
        <p>Copyright 2018 Cap-Jimb</p>

        <div id="google_translate_element"></div><script type="text/javascript" class="translate">
            function googleTranslateElementInit() {
                new google.translate.TranslateElement({pageLanguage: 'fr', includedLanguages: 'en,fr', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
            }
        </script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    </div>
</body>
</html>
