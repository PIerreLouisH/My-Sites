<section>
    <h1>Mentions Légales</h1>
    <div class="articles">
        <div class="mention-legales">
            
            <h2 class="sous_titre_mention">Concepteur</h2>        
            Société CAPJIMB <br/>
            21 Rue Marc Donadille <br/>
            13013 Marseille

            <hr/>

            <h2 class="sous_titre_mention">Hébergeur</h2>        
            Institut G4 <br/>
            21 Rue Marc Donadille <br/>
            13013 Marseille <br/>
            N° Tel : 04 84 25 00 44

            <hr/>

            <h2 class="sous_titre_mention">Propriétaire</h2> 
            <img class="img-mention" alt="societe" src="././assets/images/Capjimblogo.jpg" /> <br/>
            <div class="carte">
                <a href="index.php?action=6"><button class="btn-contact"> Contactez-nous </button></a>
            </div>
        </div>
    </div>

</section>
