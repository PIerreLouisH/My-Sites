<?php

$hote = 'localhost';
$user = 'hernandez_root';
$pass = 'qJuH8l21Ea';
$base = 'hernandez_aixetc';

?>
